#!/usr/bin/env python3
"""
sync_ares.py – Stáhne všechna SVJ a BD z ARES po prefixech názvů.
"""
import httpx, asyncio, sqlite3, json, time
from datetime import datetime

ARES_URL = "https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/vyhledat"
DB_FILE  = "prvotkar.db"
PRAVNI_FORMY = {"svj": "145", "bd": "112"}

# SVJ – většina názvů začíná "Společenství vlastníků" + adresa (číslo ulice)
# Proto číslice 1–9 jsou dominantní
PREFIXY_SVJ = [
    "Společenství vlastníků jednotek",
    "Společenství vlastníků obytného domu",
    "Společenství vlastníků bytů",
    "Společenství vlastníků bytu",
    "Společenství vlastníků domu",
    "Společenství vlastníků domů",
    "Společenství vlastníků ul",
    "Společenství vlastníků ul.",
    "Společenství vlastníků nám",
    "Společenství vlastníků A", "Společenství vlastníků B",
    "Společenství vlastníků C", "Společenství vlastníků D",
    "Společenství vlastníků E", "Společenství vlastníků F",
    "Společenství vlastníků G", "Společenství vlastníků H",
    "Společenství vlastníků Ch","Společenství vlastníků I",
    "Společenství vlastníků J", "Společenství vlastníků K",
    "Společenství vlastníků L", "Společenství vlastníků M",
    "Společenství vlastníků N", "Společenství vlastníků O",
    "Společenství vlastníků P", "Společenství vlastníků R",
    "Společenství vlastníků S", "Společenství vlastníků Š",
    "Společenství vlastníků T", "Společenství vlastníků U",
    "Společenství vlastníků V", "Společenství vlastníků Z",
    "Společenství vlastníků Ž",
    "Společenství vlastníků 1", "Společenství vlastníků 2",
    "Společenství vlastníků 3", "Společenství vlastníků 4",
    "Společenství vlastníků 5", "Společenství vlastníků 6",
    "Společenství vlastníků 7", "Společenství vlastníků 8",
    "Společenství vlastníků 9", "Společenství vlastníků 0",
    "SVJ ", "S.V.J", "Spol. vlastníků",
]

# BD – názvy jsou velmi různorodé
PREFIXY_BD = [
    # Hlavní formáty
    "Bytové družstvo",       # pokryje "Bytové družstvo X..."
    "Stavební bytové",       # "Stavební bytové družstvo"
    "Družstvo nájemníků",
    "Okresní stavební",
    "Komunální",
    # Zkratky
    "BD ", "SBD ", "SBD-", "OBD ",
    # Názvy měst (velká BD pojmenovaná po městě)
    "Praha ", "Brno ", "Ostrava ", "Plzeň",
    "Liberec", "Olomouc", "Hradec",
    "Pardubice", "České Budějovice", "Ústí",
    "Zlín", "Karviná", "Kladno", "Jihlava",
    # Další běžné formáty
    "Nájemní", "Lidové",    "Obecní",
    "Obytné",  "Vlastní",   "Domovní",
    "Horní",   "Dolní",     "Nové ",
    "Staré ",  "Malé ",     "Velké ",
    "První ",  "Druhé ",    "Třetí ",
    "1. ",     "2. ",       "3. ",
]

def init_db(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS subjekty (
            ico TEXT PRIMARY KEY, typ TEXT, nazev TEXT,
            kraj TEXT, kraj_kod TEXT, obec TEXT, cast_obce TEXT,
            ulice TEXT, cislo_popisne TEXT, cislo_orientacni TEXT,
            psc TEXT, datum_vzniku TEXT, stav TEXT,
            raw_json TEXT, updated_at TEXT
        )
    """)
    for idx in ["obec","kraj","ulice","typ","stav"]:
        conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{idx} ON subjekty({idx})")
    conn.commit()

def upsert_batch(conn, typ, items):
    now = datetime.now().isoformat()
    for item in items:
        s = item.get("sidlo") or {}
        conn.execute("""
            INSERT INTO subjekty VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(ico) DO UPDATE SET
                nazev=excluded.nazev, kraj=excluded.kraj, kraj_kod=excluded.kraj_kod,
                obec=excluded.obec, cast_obce=excluded.cast_obce, ulice=excluded.ulice,
                cislo_popisne=excluded.cislo_popisne, cislo_orientacni=excluded.cislo_orientacni,
                psc=excluded.psc, datum_vzniku=excluded.datum_vzniku, stav=excluded.stav,
                raw_json=excluded.raw_json, updated_at=excluded.updated_at
        """, (
            item.get("ico"), typ, item.get("obchodniJmeno"),
            s.get("nazevKraje"), str(s.get("kodKraje","")),
            s.get("nazevObce"), s.get("nazevCastiObce"), s.get("nazevUlice"),
            str(s.get("cisloDomovni","")), str(s.get("cisloOrientacni","")),
            str(s.get("psc","")),
            (item.get("datumVzniku") or "")[:10] or None,
            item.get("stavSubjektu"),
            json.dumps(item, ensure_ascii=False), now
        ))
    conn.commit()

async def fetch_prefix(client, conn, typ, kod_pf, prefix, retries=3):
    """Vrátí počet stažených, nebo -1 pokud příliš mnoho výsledků."""
    start = 0
    celkem = 0
    while True:
        payload = {"obchodniJmeno": prefix, "pravniForma": [kod_pf], "start": start, "pocet": 100}
        for attempt in range(retries):
            try:
                r = await client.post(ARES_URL, json=payload, timeout=30)
                break
            except Exception:
                if attempt == retries - 1: return celkem
                await asyncio.sleep(5)

        if r.status_code == 429:
            await asyncio.sleep(30); continue
        if r.status_code != 200:
            if "PRILIS_MNOHO" in r.text or "VYSTUP_PRILIS" in r.text:
                return -1
            return celkem

        data  = r.json()
        items = data.get("ekonomickeSubjekty", [])
        if not items: break

        upsert_batch(conn, typ, items)
        celkem += len(items)
        if len(items) < 100: break
        start += len(items)
        await asyncio.sleep(0.15)
    return celkem

async def sync_typ(conn, typ, kod_pf, prefixy):
    print(f"\n{'='*55}\n  {typ.upper()}  (pravniForma={kod_pf})\n{'='*55}")

    async with httpx.AsyncClient() as client:
        for i, prefix in enumerate(prefixy, 1):
            before = conn.execute("SELECT COUNT(*) FROM subjekty WHERE typ=?", [typ]).fetchone()[0]
            n = await fetch_prefix(client, conn, typ, kod_pf, prefix)

            if n == -1:
                # Rozděl na sub-prefixy (přidej další písmeno)
                sub = 0
                chars = " AÁBCČDĎEÉĚFGHIÍJKLMNŇOÓPQRŘSŠTŤUÚŮVWXYÝZŽ0123456789"
                for ch in chars:
                    n2 = await fetch_prefix(client, conn, typ, kod_pf, prefix + ch)
                    if n2 == -1:
                        # Ještě hlubší dělení
                        for ch2 in chars:
                            n3 = await fetch_prefix(client, conn, typ, kod_pf, prefix + ch + ch2)
                            if n3 > 0: sub += n3
                            await asyncio.sleep(0.1)
                    elif n2 > 0:
                        sub += n2
                    await asyncio.sleep(0.1)
                n = sub

            after = conn.execute("SELECT COUNT(*) FROM subjekty WHERE typ=?", [typ]).fetchone()[0]
            novy = after - before
            print(f"  [{i:2}/{len(prefixy)}] '{prefix[:35]}' +{novy} (DB: {after})")
            await asyncio.sleep(0.2)

    final = conn.execute("SELECT COUNT(*) FROM subjekty WHERE typ=?", [typ]).fetchone()[0]
    print(f"\n  ✅ {typ.upper()} hotovo: {final} unikátních záznamů")
    return final

async def main():
    print("🏠  Prvotkář 3.0 – Sync ARES → SQLite")
    print(f"    Databáze: {DB_FILE}  |  Začátek: {datetime.now().strftime('%H:%M:%S')}")
    print("    Stahuje po prefixech názvů (jedině spolehlivá metoda ARES).\n")

    conn = sqlite3.connect(DB_FILE)
    init_db(conn)
    t0 = time.time()

    n_svj = await sync_typ(conn, "svj", PRAVNI_FORMY["svj"], PREFIXY_SVJ)
    n_bd  = await sync_typ(conn, "bd",  PRAVNI_FORMY["bd"],  PREFIXY_BD)
    conn.close()

    elapsed = int(time.time() - t0)
    print(f"\n{'='*55}")
    print(f"✅  Sync dokončen za {elapsed//60}m {elapsed%60}s")
    print(f"    SVJ: {n_svj}  |  BD: {n_bd}  |  Celkem: {n_svj+n_bd}")
    print(f"\n👉  Nyní spusť: python3 main.py")

if __name__ == "__main__":
    asyncio.run(main())
